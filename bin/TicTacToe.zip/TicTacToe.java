import java.awt.*;
import java.awt.event.*;
import java.util.Random;

import javax.swing.*;

public class TicTacToe extends JFrame implements ActionListener {
  JPanel buttonsPanel;
  JLabel playerTurnLabel;
  JButton[] buttons = new JButton[9];
  boolean player1Turn;
  boolean gameEnded = false;
  JButton newGame, endGame;
  
  TicTacToe(){
    this.setSize(550, 550);
    this.setResizable(false);
    this.setLocationRelativeTo(rootPane);;
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.setLayout(null);

    buttonsPanel = new JPanel();
    buttonsPanel.setLayout(new GridLayout(3,3));
    buttonsPanel.setBounds(150, 50, 240, 240);
    buttonsPanel.setBackground(Color.BLACK);

    for(int i = 0; i < 9; i++){
      buttons[i] = new JButton();
      buttons[i].addActionListener(this);
      buttons[i].setFocusable(false);
      buttons[i].setFont(new Font("", Font.ITALIC, 40));
      buttons[i].setBackground(Color.CYAN);
      buttons[i].setForeground(Color.BLUE);
      buttonsPanel.add(buttons[i]);
    }

    playerTurnLabel = new JLabel();
    firstTurn();
    playerTurnLabel.setFont(new Font("Constantia", Font.ROMAN_BASELINE, 34));
    playerTurnLabel.setBounds(160, 320, 300, 40);

    newGame = new JButton("New Game");
    newGame.setBounds(150, 370, 100, 40);
    newGame.setFocusable(false);
    newGame.addActionListener(this);

    endGame = new JButton("Exit Game");
    endGame.setBounds(290, 370, 100, 40);
    endGame.setFocusable(false);
    endGame.addActionListener(this);

    this.add(buttonsPanel);
    this.add(playerTurnLabel);
    this.add(newGame);
    this.add(endGame);
    this.setVisible(true);
  }

  @Override
  public void actionPerformed(ActionEvent e) {
    if(!gameEnded){
      for(int i = 0; i < 9; i++){
        if(e.getSource() == buttons[i]){
          if(player1Turn){
            if(buttons[i].getText().equals("")){
              buttons[i].setForeground(Color.BLUE);
              buttons[i].setText("X");
              player1Turn = false;
              playerTurnLabel.setText("Player O Turn");
              checkWin();
              checkDraw();
            }
          }
          else{
            if(buttons[i].getText().equals("")){
              buttons[i].setForeground(Color.RED);
              buttons[i].setText("O");
              player1Turn = true;
              playerTurnLabel.setText("Player X Turn");
              checkWin();
              checkDraw();
            }
          }
        }
      }
    }
    if(e.getSource() == newGame){
      new TicTacToe();
      dispose();
    }else if(e.getSource() == endGame){
      this.dispose();
    }
  }
  
  public void firstTurn(){
    Random random = new Random();
    if(random.nextInt(2) == 0){
      playerTurnLabel = new JLabel("Player X Turn");
      player1Turn = true;
    }else{
      playerTurnLabel = new JLabel("Player O Turn");
      player1Turn = false;
    }
  }

  public void checkDraw(){
    if(!gameEnded){
      boolean gameDrew = true;
      for(int i = 0; i < 9; i++){
        if(buttons[i].getText().equals("")){
          gameDrew = false;
          break;
        }
        }

      if(gameDrew){
        playerTurnLabel.setBounds(210, 320, 300, 40);
        playerTurnLabel.setText("A Draw");
        gameEnded = true;
      }
    }
  }

  public void checkWin(){
    // horizontal check for x
    if(buttons[0].getText() == "X" && buttons[1].getText() == "X" && buttons[2].getText() == "X"){
      playerTurnLabel.setText("Player X wins");
      xWins(0, 1, 2);
      return;
    }
    if(buttons[3].getText() == "X" && buttons[4].getText() == "X" && buttons[5].getText() == "X"){
      playerTurnLabel.setText("Player X wins");
      xWins(3, 4, 5);
      return;
    }
    if(buttons[6].getText() == "X" && buttons[7].getText() == "X" && buttons[8].getText() == "X"){
      playerTurnLabel.setText("Player X wins");
      xWins(6, 7, 8);
      return;
    }

    // vertical check for x
    if(buttons[0].getText() == "X" && buttons[3].getText() == "X" && buttons[6].getText() == "X"){
      playerTurnLabel.setText("Player X wins");
      xWins(0, 3, 6);
      return;
    }
    if(buttons[1].getText() == "X" && buttons[4].getText() == "X" && buttons[7].getText() == "X"){
      playerTurnLabel.setText("Player X wins");
      xWins(1, 4, 7);
      return;
    }
    if(buttons[2].getText() == "X" && buttons[5].getText() == "X" && buttons[8].getText() == "X"){
      playerTurnLabel.setText("Player X wins");
      xWins(2, 5, 8);
      return;
    }

    //diagonal check for x
    if(buttons[0].getText() == "X" && buttons[4].getText() == "X" && buttons[8].getText() == "X"){
      playerTurnLabel.setText("Player X wins");
      xWins(0, 4, 8);
      return;
    }
    if(buttons[2].getText() == "X" && buttons[4].getText() == "X" && buttons[6].getText() == "X"){
      playerTurnLabel.setText("Player X wins");
      xWins(2, 4, 6);
      return;
    }

    /* ************************************************************************************* */

    // horizontal check for O
    if(buttons[0].getText() == "O" && buttons[1].getText() == "O" && buttons[2].getText() == "O"){
      playerTurnLabel.setText("Player O wins");
      oWins(0, 1, 2);
      return;
    }
    if(buttons[3].getText() == "O" && buttons[4].getText() == "O" && buttons[5].getText() == "O"){
      playerTurnLabel.setText("Player O wins");
      oWins(3, 4, 5);
      return;
    }
    if(buttons[6].getText() == "O" && buttons[7].getText() == "O" && buttons[8].getText() == "O"){
      playerTurnLabel.setText("Player O wins");
      oWins(6, 7, 8);
      return;
    }

    // vertical check for O
    if(buttons[0].getText() == "O" && buttons[3].getText() == "O" && buttons[6].getText() == "O"){
      playerTurnLabel.setText("Player O wins");
      oWins(0, 3, 6);
      return;
    }
    if(buttons[1].getText() == "O" && buttons[4].getText() == "O" && buttons[7].getText() == "O"){
      playerTurnLabel.setText("Player O wins");
      oWins(1, 4, 7);
      return;
    }
    if(buttons[2].getText() == "O" && buttons[5].getText() == "O" && buttons[8].getText() == "O"){
      playerTurnLabel.setText("Player O wins");
      oWins(2, 5, 8);
      return;
    }

    //diagonal check for O
    if(buttons[0].getText() == "O" && buttons[4].getText() == "O" && buttons[8].getText() == "O"){
      playerTurnLabel.setText("Player O wins");
      oWins(0, 4, 8);
      return;
    }
    if(buttons[2].getText() == "O" && buttons[4].getText() == "O" && buttons[6].getText() == "O"){
      playerTurnLabel.setText("Player O wins");
      oWins(2, 4, 6);
      return;
    }
  }

  public void xWins(int a, int b, int c){
    buttons[a].setForeground(Color.yellow);
    buttons[a].setBackground(Color.black);

    buttons[b].setForeground(Color.yellow);
    buttons[b].setBackground(Color.black);

    buttons[c].setForeground(Color.yellow);
    buttons[c].setBackground(Color.black);

    gameEnded = true;
  }
  
  public void oWins(int a, int b, int c){
    buttons[a].setForeground(Color.yellow);
    buttons[a].setBackground(Color.black);

    buttons[b].setForeground(Color.yellow);
    buttons[b].setBackground(Color.black);

    buttons[c].setForeground(Color.yellow);
    buttons[c].setBackground(Color.black);

    gameEnded = true;
  }

  public static void main(String[] args) {
    new TicTacToe();
  }
}
